
package AlquilerVehiculos;
import java.io.Serializable;
public class RegistroDeAlquiler implements Serializable {
    private Persona p=new Persona();
    private int limiteAlquiler=5;
     private int nroAutos,nroMotos,nroCamiones,totalVehiculos;
    private Camion c[]=new Camion[5];
    private Auto a[]=new Auto[5];
    private Moto m[]=new Moto[5];
    public RegistroDeAlquiler(){}
    public RegistroDeAlquiler(Persona x){
        p=x;
        nroAutos=0;nroMotos=0;nroCamiones=0;totalVehiculos=0;
    }
    public void mostrar(){
        System.out.println("Persona : ");
        p.mostrar();
        System.out.println("");
        System.out.println("Vehiculos alquilados: "+totalVehiculos);
        System.out.println("");
        System.out.println("Autos: ");
        System.out.println("Cantidad: "+nroAutos);
        for(int i=0;i<nroAutos;i++){
            a[i].mostrar();
        }
        System.out.println("");
        System.out.println("Motos: ");
        System.out.println("Cantidad: "+nroMotos);
        for(int i=0;i<nroMotos;i++){
            m[i].mostrar();
        }
        System.out.println("");
        System.out.println("Camiones: ");
        System.out.println("Cantidad: "+nroCamiones);
        for(int i=0;i<nroCamiones;i++){
            c[i].mostrar();
        }
    }
    public void alquilarCamion(Camion x){
        if(totalVehiculos<limiteAlquiler)
            {c[nroCamiones]=x;
            nroCamiones++;
            totalVehiculos++;}
        else{System.out.println("Ya paso el limite de alquiler...");}
    }
    public void alquilarAuto(Auto x){
        if(totalVehiculos<limiteAlquiler)
            {a[nroAutos]=x;
            nroAutos++;
            totalVehiculos++;}
        else{System.out.println("Ya paso el limite de alquiler...");}
    }
    public void alquilarMoto(Moto x){
        if(totalVehiculos<limiteAlquiler)
            {m[nroMotos]=x;
            nroMotos++;
            totalVehiculos++;}
        else{System.out.println("Ya paso el limite de alquiler...");}
    }
    public void mostrarVehiculos(){
        System.out.println("Autos: ");
        System.out.println("Cantidad: "+nroAutos);
        for(int i=0;i<nroAutos;i++){
            a[i].mostrar();
        }
        System.out.println("");
        System.out.println("Motos: ");
        System.out.println("Cantidad: "+nroMotos);
        for(int i=0;i<nroMotos;i++){
            m[i].mostrar();
        }
        System.out.println("");
        System.out.println("Camiones: ");
        System.out.println("Cantidad: "+nroCamiones);
        for(int i=0;i<nroCamiones;i++){
            c[i].mostrar();
        }
    }

    public Persona getP() {
        return p;
    }

    public void setP(Persona p) {
        this.p = p;
    }

    public int getLimiteAlquiler() {
        return limiteAlquiler;
    }

    public void setLimiteAlquiler(int limiteAlquiler) {
        this.limiteAlquiler = limiteAlquiler;
    }

    public int getNroAutos() {
        return nroAutos;
    }

    public void setNroAutos(int nroAutos) {
        this.nroAutos = nroAutos;
    }

    public int getNroMotos() {
        return nroMotos;
    }

    public void setNroMotos(int nroMotos) {
        this.nroMotos = nroMotos;
    }

    public int getNroCamiones() {
        return nroCamiones;
    }

    public void setNroCamiones(int nroCamiones) {
        this.nroCamiones = nroCamiones;
    }

    public int getTotalVehiculos() {
        return totalVehiculos;
    }

    public void setTotalVehiculos(int totalVehiculos) {
        this.totalVehiculos = totalVehiculos;
    }

    public Camion getC(int i) {
        return c[i];
    }

    public void setC(Camion c,int i) {
        this.c [i]= c;
    }

    public Auto getA(int i) {
        return a[i];
    }

    public void setA(Auto a,int i) {
        this.a[i]= a;
    }

    public Moto getM(int i) {
        return m[i];
    }

    public void setM(Moto m, int i) {
        this.m[i] = m;
    }

    
}
