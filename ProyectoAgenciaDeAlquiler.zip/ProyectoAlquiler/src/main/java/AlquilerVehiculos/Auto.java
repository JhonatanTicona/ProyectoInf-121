
package AlquilerVehiculos;
import java.io.Serializable;
public class Auto extends Vehiculo implements Serializable{
    private String tipo,alquilado;
    
    public Auto(){}
    public Auto(String marca,String modelo,String color,int año,String placa,int capacidad,int precio,String tipo){
        super(marca,modelo,color,año,placa,capacidad,precio);
        this.tipo=tipo;
        alquilado="no";
    }
    public void mostrar(){
        super.mostrar();
        System.out.println(" Tipo: "+tipo+" Alquilado:"+alquilado);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getAlquilado() {
        return alquilado;
    }

    public void setAlquilado(String alquilado) {
        this.alquilado = alquilado;
    }
    
}
