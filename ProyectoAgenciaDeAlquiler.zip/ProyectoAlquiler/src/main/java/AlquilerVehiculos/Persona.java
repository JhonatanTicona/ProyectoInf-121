
package AlquilerVehiculos;
import java.io.Serializable;
public class Persona implements Serializable{
    protected String nombre,apellido;
    protected int edad,nroCelular,ci;
    
    public Persona(){}
    public Persona(String nombre,String apellido,int edad,int nroCelular,int ci){
        this.nombre=nombre;
        this.apellido=apellido;
        this.edad=edad;
        this.nroCelular=nroCelular;
        this.ci=ci;
    }
    public void mostrar(){
        System.out.print("Nombre: "+nombre+" Apellido: "+apellido+" Edad: "+edad+" Numero de Celular: "+nroCelular+" Ci: "+ci);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getNroCelular() {
        return nroCelular;
    }

    public void setNroCelular(int nroCelular) {
        this.nroCelular = nroCelular;
    }

    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }
    
}
