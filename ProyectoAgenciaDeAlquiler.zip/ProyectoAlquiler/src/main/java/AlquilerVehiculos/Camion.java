
package AlquilerVehiculos;
import java.io.Serializable;
public class Camion extends Vehiculo implements Serializable{
    private String alquilado,cargamento;
    public Camion(){}
    public Camion(String marca,String modelo,String color,int año,String placa,int capacidad,int precio,String cargamento){
        super(marca,modelo,color,año,placa,capacidad,precio);
        this.cargamento=cargamento;
        alquilado="no";
    }
    public void mostrar(){
        super.mostrar();
        System.out.println(" Cargamento: "+cargamento+" Alquilado: "+alquilado);
    }


    public String getCargamento() {
        return cargamento;
    }

    public void setCargamento(String cargamento) {
        this.cargamento = cargamento;
    }

    public String getAlquilado() {
        return alquilado;
    }

    public void setAlquilado(String alquilado) {
        this.alquilado = alquilado;
    }
    
}
