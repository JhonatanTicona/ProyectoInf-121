
package AlquilerVehiculos;
import java.io.Serializable;
public class Empleado extends Persona implements Serializable{
    private int añosdeXp,salario;
    
    public Empleado(){}
    public Empleado(String nombre,String apellido,int edad,int nroCelular,int ci,int añosdeXp,int salario){
        super(nombre,apellido,edad,nroCelular,ci);
        this.añosdeXp=añosdeXp;
        this.salario=salario;
    }
    public void mostrar(){
        super.mostrar();
        System.out.println("Años de Experiencia: "+añosdeXp);
    }

    public int getAñosdeXp() {
        return añosdeXp;
    }

    public void setAñosdeXp(int añosdeXp) {
        this.añosdeXp = añosdeXp;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
    
}
