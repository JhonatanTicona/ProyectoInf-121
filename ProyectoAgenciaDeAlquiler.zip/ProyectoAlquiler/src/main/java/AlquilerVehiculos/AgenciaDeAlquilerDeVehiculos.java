
package AlquilerVehiculos;
import java.io.Serializable;
public class AgenciaDeAlquilerDeVehiculos implements Serializable {
    private String nombre;
    private int nroEmpleados,nroAutos,nroMotos,nroCamiones,totalVehiculos,CapacidadMaxima,nroRegistroAlquiler;
    private Empleado e[]=new Empleado[40];
    private Camion c[]=new Camion[10];
    private Auto a[]=new Auto[30];
    private Moto m[]=new Moto[20];
    private RegistroDeAlquiler r[]= new RegistroDeAlquiler[100];
    public AgenciaDeAlquilerDeVehiculos(  ){ 
        for(int i=0;i<40;i++){
            e[i]=new Empleado();
        }
        for(int i=0;i<10;i++){
            c[i]=new Camion();
        }
        for(int i=0;i<30;i++){
            a[i]=new Auto();
        }
        for(int i=0;i<20;i++){
            m[i]=new Moto();
        }
        for(int i=0;i<100;i++){
            r[i]=new RegistroDeAlquiler();
        }
    }
    public AgenciaDeAlquilerDeVehiculos(String nombre,int CapacidadMaxima){
        this.nombre=nombre;
        nroEmpleados=0;
        nroAutos=0;
        nroMotos=0;
        nroCamiones=0;
        nroRegistroAlquiler=0;
        this.CapacidadMaxima=CapacidadMaxima;
    }
    public void mostrar(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Numero de Empleados: "+nroEmpleados);
        System.out.println("Cantidad de Vehiculos: "+totalVehiculos);
        System.out.println("Capacidad Maxima: "+CapacidadMaxima);
        System.out.println("Registro de Alquileres: "+nroRegistroAlquiler);
    }
    public void mostrarVehiculos(){
        System.out.println("Autos: ");
        System.out.println("Cantidad: "+nroAutos);
        for(int i=0;i<nroAutos;i++){
            a[i].mostrar();
        }
        System.out.println("");
        System.out.println("Motos: ");
        System.out.println("Cantidad: "+nroMotos);
        for(int i=0;i<nroMotos;i++){
            m[i].mostrar();
        }
        System.out.println("");
        System.out.println("Camiones: ");
        System.out.println("Cantidad: "+nroCamiones);
        for(int i=0;i<nroCamiones;i++){
            c[i].mostrar();
        }
    }
    public void mostrarEmpleados(){
        System.out.println("Empleados: ");
        System.out.println("Cantidad: "+nroEmpleados);
        for(int i=0;i<nroEmpleados;i++){
            e[i].mostrar();
        }
    }
    public void mostrarAutos(){
        System.out.println("Autos: ");
        System.out.println("Cantidad: "+nroAutos);
        for(int i=0;i<nroAutos;i++){
            a[i].mostrar();
        }
    }
    public void mostrarMotos(){
        System.out.println("Motos: ");
        System.out.println("Cantidad: "+nroMotos);
        for(int i=0;i<nroMotos;i++){
            m[i].mostrar();
        }
    }
    public void mostrarCamiones(){
        System.out.println("Camiones: ");
        System.out.println("Cantidad: "+nroCamiones);
        for(int i=0;i<nroCamiones;i++){
            c[i].mostrar();
        }
    }
    public void mostrarAlquileres(){
        System.out.println("Registro de Alquileres: ");
        System.out.println("Nrumero de Alquileres: "+nroRegistroAlquiler);
        for(int i=0;i<nroRegistroAlquiler;i++){
            r[i].mostrar();
        }
    }
    public void agregarEmpleado(Empleado x){
        e[nroEmpleados]=x;
        nroEmpleados++;
    }
    public void agregarCamion(Camion x){
        c[nroCamiones]=x;
        nroCamiones++;
    }
    public void agregarAuto(Auto x){
        a[nroAutos]=x;
        nroAutos++;
    }
    public void agregarMoto(Moto x){
        m[nroMotos]=x;
        nroMotos++;
    }

    public String getNombre() {
        return nombre;
    }
    public void AgregarRegistroDeAlquiler(Persona p){
        r[nroRegistroAlquiler]=new RegistroDeAlquiler(p);
        nroRegistroAlquiler++;
    }
    public void alquilarVehiculo(String nombre,String apellido,Moto m){
        for(int i=0;i<nroRegistroAlquiler;i++){
            Persona x=new Persona();
            x=r[i].getP();
            if(x.getNombre().equals(nombre)&&x.getApellido().equals(apellido)){
                r[i].alquilarMoto(m);
            }
        }
    }
    public void alquilarVehiculo(String nombre,String apellido,Auto a){
        for(int i=0;i<nroRegistroAlquiler;i++){
            Persona x=new Persona();
            x=r[i].getP();
            if(x.getNombre().equals(nombre)&&x.getApellido().equals(apellido)){
                r[i].alquilarAuto(a);
            }
        }
    }
    public void alquilarVehiculo(String nombre,String apellido,Camion c){
        for(int i=0;i<nroRegistroAlquiler;i++){
            Persona x=new Persona();
            x=r[i].getP();
            if(x.getNombre().equals(nombre)&&x.getApellido().equals(apellido)){
                r[i].alquilarCamion(c);
            }
        }
    }
    public void EliminarEmpleado(String nombre, String apellido) {
    for (int i = nroEmpleados - 1; i >= 0; i--) {
        if (e[i].getNombre().equals(nombre) && e[i].getApellido().equals(apellido)) {
            for (int j = i; j < nroEmpleados -1; j++) {
                e[j] = e[j + 1];
            }
            e[nroEmpleados - 1] = null; 
            nroEmpleados--;
            break; 
        }
    }
}
    public void EliminarAuto(String placa) {
    for (int i = nroAutos - 1; i >= 0; i--) {
        if (a[i].getPlaca().equals(placa)) {
            for (int j = i; j < nroAutos -1; j++) {
                a[j] = a[j + 1];
            }
            a[nroAutos - 1] = null; 
            nroAutos--;
            break; 
        }
    }
}
    public void EliminarMoto(String placa) {
    for (int i = nroMotos - 1; i >= 0; i--) {
        if (m[i].getPlaca().equals(placa)) {
            for (int j = i; j < nroMotos -1; j++) {
                m[j] = m[j + 1];
            }
            m[nroMotos - 1] = null; 
            nroMotos--;
            break; 
        }
    }
}
    public void EliminarCamion(String placa) {
    for (int i = nroCamiones - 1; i >= 0; i--) {
        if (c[i].getPlaca().equals(placa)) {
            for (int j = i; j < nroCamiones -1; j++) {
                c[j] = c[j + 1];
            }
            c[nroCamiones - 1] = null; 
            nroCamiones--;
            break; 
        }
    }
}
    public void EliminarRegistro(String nombre, String apellido) {
    for (int i = nroRegistroAlquiler - 1; i >= 0; i--) {
        Persona p=r[i].getP();
        if (p.getNombre().equals(nombre) && p.getApellido().equals(apellido)) {
            for (int j = 0; j < r[i].getNroAutos() ; j++) {
                Auto au=r[i].getA(j);
                for(int f=0;f<nroAutos;f++){
                    if(au.getPlaca().equals(a[f].getPlaca()))
                    {a[f].setAlquilado("no");
                    }
                }
            }
            for (int j = 0; j < r[i].getNroMotos() ; j++) {
                Moto mo=r[i].getM(j);
                for(int f=0;f<nroMotos;f++){
                    if(mo.getPlaca().equals(m[f].getPlaca()))
                    {m[f].setAlquilado("no");
                    }
                }
            }
            for (int j = 0; j < r[i].getNroCamiones() ; j++) {
                Camion ca=r[i].getC(j);
                for(int f=0;f<nroCamiones;f++){
                    if(ca.getPlaca().equals(c[f].getPlaca()))
                    {c[f].setAlquilado("no");
                    }
                }
            }
            for (int j = i; j < nroRegistroAlquiler -1; j++) {
                r[j] = r[j + 1];
            }
            r[nroRegistroAlquiler - 1] = null; 
            nroRegistroAlquiler--;
            break; 
        }
    }
}
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNroEmpleados() {
        return nroEmpleados;
    }

    public void setNroEmpleados(int nroEmpleados) {
        this.nroEmpleados = nroEmpleados;
    }

    public int getNroAutos() {
        return nroAutos;
    }

    public void setNroAutos(int nroAutos) {
        this.nroAutos = nroAutos;
    }

    public int getNroMotos() {
        return nroMotos;
    }

    public void setNroMotos(int nroMotos) {
        this.nroMotos = nroMotos;
    }

    public int getNroCamiones() {
        return nroCamiones;
    }

    public void setNroCamiones(int nroCamiones) {
        this.nroCamiones = nroCamiones;
    }

    public Empleado getE(int i) {
        return e[i];
    }

    public void setE(Empleado e,int i) {
        this.e[i] = e;
    }

    public Camion getC(int i) {
        return c[i];
    }

    public void setC(Camion c,int i) {
        this.c [i]= c;
    }

    public Auto getA(int i) {
        return a[i];
    }

    public void setA(Auto a,int i) {
        this.a[i]= a;
    }

    public Moto getM(int i) {
        return m[i];
    }

    public void setM(Moto m, int i) {
        this.m[i] = m;
    }

    public int getTotalVehiculos() {
        return totalVehiculos;
    }

    public void setTotalVehiculos(int totalVehiculos) {
        this.totalVehiculos = totalVehiculos;
    }

    public int getCapacidadMaxima() {
        return CapacidadMaxima;
    }

    public void setCapacidadMaxima(int CapacidadMaxima) {
        this.CapacidadMaxima = CapacidadMaxima;
    }

    public int getNroRegistroAlquiler() {
        return nroRegistroAlquiler;
    }

    public void setNroRegistroAlquiler(int nroRegistroAlquiler) {
        this.nroRegistroAlquiler = nroRegistroAlquiler;
    }

    public RegistroDeAlquiler getR(int i) {
        return r[i];
    }

    public void setR(RegistroDeAlquiler r,int i) {
        this.r [i]= r;
    }
        
    
}
