
package AlquilerVehiculos;
import java.io.Serializable;
public class Vehiculo implements Serializable{
    protected String marca,modelo,color,placa;
    protected int año,capacidad,precio;
    
    
    public Vehiculo(){}
    public Vehiculo(String marca,String modelo,String color,int año,String placa,int capacidad,int precio){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
        this.año=año;
        this.placa=placa;
        this.capacidad=capacidad;
        this.precio=precio;
    }
    public void mostrar(){
        System.out.print("Marca: "+marca+" Modelo: "+modelo+" Color: "+color+" Año: "+año+" Placa: "+placa+" Capacidad: "+capacidad+" Precio: "+precio);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
}
