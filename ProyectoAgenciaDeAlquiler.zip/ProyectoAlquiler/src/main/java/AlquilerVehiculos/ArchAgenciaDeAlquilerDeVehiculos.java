/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AlquilerVehiculos;

import java.io.*;
import javax.swing.JOptionPane;

public class ArchAgenciaDeAlquilerDeVehiculos {

    private String nomArch;

    public ArchAgenciaDeAlquilerDeVehiculos() {
        this.nomArch = "archivoAgencia2.dat";
    }

    public void crear() throws FileNotFoundException, IOException {
        ObjectOutputStream arch = new ObjectOutputStream(new FileOutputStream(nomArch));
        arch.close();
    }

    public void listar() throws IOException, ClassNotFoundException {
        if (!new File(nomArch).exists()) {
            System.out.println("No hay datos para mostrar.");
            return;
        }

        try (ObjectInputStream arch = new ObjectInputStream(new FileInputStream(nomArch))) {
            while (true) {
                AgenciaDeAlquilerDeVehiculos m = (AgenciaDeAlquilerDeVehiculos) arch.readObject();
                m.mostrar();
            }
        } catch (EOFException e) {
        
        }

    }

    public void AgregarAgencia(String nombre, int capacidadMax) throws IOException, ClassNotFoundException {
        File f = new File(nomArch);
        boolean append = f.exists() && f.length() > 0;

        try (ObjectOutputStream arch = append
                ? new AppendableObjectOutputStream(new FileOutputStream(f, true))
                : new ObjectOutputStream(new FileOutputStream(f))) {

            AgenciaDeAlquilerDeVehiculos nuevo = new AgenciaDeAlquilerDeVehiculos(nombre, capacidadMax);
            arch.writeObject(nuevo);
        }
    }

    class AppendableObjectOutputStream extends ObjectOutputStream {

        public AppendableObjectOutputStream(OutputStream out) throws IOException {
            super(out);
        }

        @Override
        protected void writeStreamHeader() throws IOException {
            reset();
        }
    }
public void AgregarEmpleado(String nombreAgencia, String nombre, String apellido, int edad, int nroCelular, int ci, int añosdeXp, int salario)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAux = new File("aux.dat");
    boolean encontrado = false;

    try (
        ObjectInputStream arch = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream archAux = new ObjectOutputStream(new FileOutputStream(archivoAux))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia;
            try {
                agencia = (AgenciaDeAlquilerDeVehiculos) arch.readObject();
            } catch (EOFException e) {
                break;
            }

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                Empleado nuevoEmpleado = new Empleado(nombre, apellido, edad, nroCelular, ci, añosdeXp, salario);
                agencia.agregarEmpleado(nuevoEmpleado);
                encontrado = true;
            }

            archAux.writeObject(agencia);
        }
    } // ← Aquí se cierran los archivos automáticamente

    // Esperar un poco o forzar el recolector de basura (opcional)
    System.gc();
    try { Thread.sleep(100); } catch (InterruptedException ignored) {}

    // Intentar reemplazar
    if (!archivoOriginal.delete()) {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
        return;
    }

    if (!archivoAux.renameTo(archivoOriginal)) {
        JOptionPane.showMessageDialog(null, "Error al renombrar archivo auxiliar.");
        return;
    }

    if (encontrado) {
        JOptionPane.showMessageDialog(null, "Empleado agregado correctamente a la agencia " + nombreAgencia);
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    }
}
    public void AgregarAuto(String nombreAgencia, String marca, String modelo, String color, int año, String placa, int capacidad,int precio, String tipo)
            throws IOException, ClassNotFoundException {

        File archivoOriginal = new File(nomArch);
        File archivoAux = new File("aux.dat");
        boolean encontrado = false;

        try (
                ObjectInputStream arch = new ObjectInputStream(new FileInputStream(archivoOriginal)); ObjectOutputStream archAux = new ObjectOutputStream(new FileOutputStream(archivoAux))) {
            while (true) {
                AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) arch.readObject();

                if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                    Auto nuevoAuto = new Auto(marca, modelo, color, año, placa, capacidad,precio, tipo);
                    agencia.agregarAuto(nuevoAuto);
                    encontrado = true;
                }

                archAux.writeObject(agencia);
            }

        } catch (EOFException e) {
            // fin de archivo
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al agregar auto: " + e.getMessage());
            throw e;
        }

        // Reemplazar archivo original
        if (archivoOriginal.delete()) {
            if (!archivoAux.renameTo(archivoOriginal)) {
                JOptionPane.showMessageDialog(null, "Error al renombrar archivo auxiliar.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
        }

        if (encontrado) {
            JOptionPane.showMessageDialog(null, "Auto agregado correctamente a la agencia " + nombreAgencia);
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
        }
    }
public void AgregarMoto(String nombreAgencia, String marca, String modelo, String color, int año, String placa, int capacidad,int precio, String tipo)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAux = new File("aux.dat");
    boolean encontrado = false;

    try (
        ObjectInputStream arch = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream archAux = new ObjectOutputStream(new FileOutputStream(archivoAux))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) arch.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                Moto nuevaMoto = new Moto(marca, modelo, color, año, placa, capacidad,precio, tipo);
                agencia.agregarMoto(nuevaMoto);
                encontrado = true;
            }

            archAux.writeObject(agencia);
        }

    } catch (EOFException e) {
        // Fin del archivo alcanzado, es normal
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al agregar moto: " + e.getMessage());
        throw e;
    }

    // Reemplazar archivo original
    if (archivoOriginal.delete()) {
        if (!archivoAux.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "Error al renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    if (encontrado) {
        JOptionPane.showMessageDialog(null, "Moto agregada correctamente a la agencia " + nombreAgencia);
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    }
}
   public void AgregarCamion(String nombreAgencia, String marca, String modelo, String color, int año, String placa, int capacidad,int precio, String cargamento)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAuxiliar = new File("aux.dat");
    boolean encontrado = false;

    try (
        ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(archivoAuxiliar))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) lector.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                Camion camion = new Camion(marca, modelo, color, año, placa, capacidad,precio, cargamento);
                agencia.agregarCamion(camion);
                encontrado = true;
            }

            escritor.writeObject(agencia);
        }
    } catch (EOFException e) {
        // Fin de archivo: no hacer nada
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al agregar el camión: " + e.getMessage());
        throw e;
    }

    // Reemplazar archivo original con el auxiliar
    if (archivoOriginal.delete()) {
        if (!archivoAuxiliar.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "No se pudo renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    // Mensaje final
    if (encontrado) {
        JOptionPane.showMessageDialog(null, "Camión agregado correctamente a la agencia " + nombreAgencia);
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    }
}
public void AgregarRegistroDeAlquiler(String nombreAgencia, Persona persona)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAuxiliar = new File("aux.dat");
    boolean encontrado = false;

    try (
        ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(archivoAuxiliar))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) lector.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                agencia.AgregarRegistroDeAlquiler(persona);
                encontrado = true;
            }

            escritor.writeObject(agencia);
        }
    } catch (EOFException e) {
        // Fin del archivo, continuar
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al agregar registro: " + e.getMessage());
        throw e;
    }

    // Reemplazar el archivo original
    if (archivoOriginal.delete()) {
        if (!archivoAuxiliar.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "No se pudo renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    if (encontrado) {
        JOptionPane.showMessageDialog(null, "Registro de alquiler agregado correctamente a la agencia " + nombreAgencia);
    } else {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    }
}
public void AgregarAutoRegistroDeAlquiler(String nombreAgencia, String nombrePersona, String apellidoPersona, Auto auto)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAuxiliar = new File("aux.dat");
    boolean agenciaEncontrada = false;
    boolean personaEncontrada = false;

    try (
        ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(archivoAuxiliar))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) lector.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                agenciaEncontrada = true;

                for (int i = 0; i < agencia.getNroRegistroAlquiler(); i++) {
                    RegistroDeAlquiler registro = agencia.getR(i);
                    Persona persona = registro.getP();

                    if (persona.getNombre().equalsIgnoreCase(nombrePersona)
                            && persona.getApellido().equalsIgnoreCase(apellidoPersona)) {

                        personaEncontrada = true;

                        if (auto.getAlquilado().equalsIgnoreCase("no")) {
                            registro.alquilarAuto(auto);
                            auto.setAlquilado("si");
                        } else {
                            JOptionPane.showMessageDialog(null, "El auto ya está alquilado.");
                        }
                    }
                }
            }

            escritor.writeObject(agencia);
        }

    } catch (EOFException e) {
        // Fin del archivo, comportamiento esperado
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al alquilar el auto: " + e.getMessage());
        throw e;
    }

    // Reemplazar archivo original
    if (archivoOriginal.delete()) {
        if (!archivoAuxiliar.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "No se pudo renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    if (!agenciaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    } else if (!personaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la persona: " + nombrePersona + " " + apellidoPersona);
    } else {
        JOptionPane.showMessageDialog(null, "Auto alquilado correctamente a " + nombrePersona + " " + apellidoPersona);
    }
}  
   public void AgregarMotoRegistroDeAlquiler(String nombreAgencia, String nombrePersona, String apellidoPersona, Moto moto)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAuxiliar = new File("aux.dat");
    boolean agenciaEncontrada = false;
    boolean personaEncontrada = false;

    try (
        ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(archivoAuxiliar))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) lector.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                agenciaEncontrada = true;

                for (int i = 0; i < agencia.getNroRegistroAlquiler(); i++) {
                    RegistroDeAlquiler registro = agencia.getR(i);
                    Persona persona = registro.getP();

                    if (persona.getNombre().equalsIgnoreCase(nombrePersona)
                            && persona.getApellido().equalsIgnoreCase(apellidoPersona)) {

                        personaEncontrada = true;

                        if (moto.getAlquilado().equalsIgnoreCase("no")) {
                            registro.alquilarMoto(moto);
                            moto.setAlquilado("si");
                        } else {
                            JOptionPane.showMessageDialog(null, "La moto ya está alquilada.");
                        }
                    }
                }
            }

            escritor.writeObject(agencia);
        }

    } catch (EOFException e) {
        // Fin del archivo
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al alquilar la moto: " + e.getMessage());
        throw e;
    }

    // Reemplazar archivo
    if (archivoOriginal.delete()) {
        if (!archivoAuxiliar.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "No se pudo renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    // Mostrar resultado final
    if (!agenciaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    } else if (!personaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la persona: " + nombrePersona + " " + apellidoPersona);
    } else {
        JOptionPane.showMessageDialog(null, "Moto alquilada correctamente a " + nombrePersona + " " + apellidoPersona);
    }
}
public void AgregarCamionRegistroDeAlquiler(String nombreAgencia, String nombrePersona, String apellidoPersona, Camion camion)
        throws IOException, ClassNotFoundException {

    File archivoOriginal = new File(nomArch);
    File archivoAuxiliar = new File("aux.dat");
    boolean agenciaEncontrada = false;
    boolean personaEncontrada = false;

    try (
        ObjectInputStream lector = new ObjectInputStream(new FileInputStream(archivoOriginal));
        ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream(archivoAuxiliar))
    ) {
        while (true) {
            AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) lector.readObject();

            if (agencia.getNombre().equalsIgnoreCase(nombreAgencia)) {
                agenciaEncontrada = true;

                for (int i = 0; i < agencia.getNroRegistroAlquiler(); i++) {
                    RegistroDeAlquiler registro = agencia.getR(i);
                    Persona persona = registro.getP();

                    if (persona.getNombre().equalsIgnoreCase(nombrePersona)
                            && persona.getApellido().equalsIgnoreCase(apellidoPersona)) {

                        personaEncontrada = true;

                        if (camion.getAlquilado().equalsIgnoreCase("no")) {
                            registro.alquilarCamion(camion);
                            camion.setAlquilado("si");
                        } else {
                            JOptionPane.showMessageDialog(null, "El camión ya está alquilado.");
                        }
                    }
                }
            }

            escritor.writeObject(agencia);
        }
    } catch (EOFException e) {
        // Fin del archivo esperado
    } catch (IOException | ClassNotFoundException e) {
        JOptionPane.showMessageDialog(null, "Error al alquilar el camión: " + e.getMessage());
        throw e;
    }

    // Reemplazar archivo original con auxiliar
    if (archivoOriginal.delete()) {
        if (!archivoAuxiliar.renameTo(archivoOriginal)) {
            JOptionPane.showMessageDialog(null, "No se pudo renombrar el archivo auxiliar.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No se pudo eliminar el archivo original.");
    }

    if (!agenciaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la agencia con nombre: " + nombreAgencia);
    } else if (!personaEncontrada) {
        JOptionPane.showMessageDialog(null, "No se encontró la persona: " + nombrePersona + " " + apellidoPersona);
    } else {
        JOptionPane.showMessageDialog(null, "Camión alquilado correctamente a " + nombrePersona + " " + apellidoPersona);
    }
}
  
    public String getNomArch() {
        return nomArch;
    }

    public void setNomArch(String nomArch) {
        this.nomArch = nomArch;
    }

}
