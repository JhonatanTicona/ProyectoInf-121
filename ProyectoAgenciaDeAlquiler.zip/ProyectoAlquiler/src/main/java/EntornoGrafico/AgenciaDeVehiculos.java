/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package EntornoGrafico;

import AlquilerVehiculos.*;
import java.io.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class AgenciaDeVehiculos extends javax.swing.JFrame {

    private ArchAgenciaDeAlquilerDeVehiculos ArchAgen = new ArchAgenciaDeAlquilerDeVehiculos();
    private AgenciaDeAlquilerDeVehiculos A[] = new AgenciaDeAlquilerDeVehiculos[10];
    private int nroAgen = 0;

    public AgenciaDeVehiculos() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        BotonCargarDatos = new javax.swing.JButton();
        Titulo = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        AreaDeDatosDeAgencia = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TablaEmpleados = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        TablaRegistro = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        TablaMotos = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        TablaAutos = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        TablaCamiones = new javax.swing.JTable();
        BotonActualizarDatos = new javax.swing.JButton();
        BarraMenu = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        AgregarAgencia = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        AgregarEmpleado = new javax.swing.JMenuItem();
        AgregarRegistro = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        AgregarAuto = new javax.swing.JMenuItem();
        AgregarMoto = new javax.swing.JMenuItem();
        AgregarCamion = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        AlquilarAuto = new javax.swing.JMenuItem();
        AlquilarMoto = new javax.swing.JMenuItem();
        AlquilarCamion = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        EliminarEmpleado = new javax.swing.JMenuItem();
        EliminarRegistro = new javax.swing.JMenuItem();
        EliminarAuto = new javax.swing.JMenuItem();
        EliminarMoto = new javax.swing.JMenuItem();
        EliminarCamion = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 255, 255));

        BotonCargarDatos.setBackground(new java.awt.Color(0, 102, 255));
        BotonCargarDatos.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        BotonCargarDatos.setText("Cargar Datos");
        BotonCargarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCargarDatosActionPerformed(evt);
            }
        });

        Titulo.setFont(new java.awt.Font("Verdana", 3, 50)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 102, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Titulo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        AreaDeDatosDeAgencia.setColumns(20);
        AreaDeDatosDeAgencia.setRows(5);
        AreaDeDatosDeAgencia.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 102, 255), 3));
        jScrollPane4.setViewportView(AreaDeDatosDeAgencia);

        jButton1.setBackground(new java.awt.Color(51, 204, 255));
        jButton1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Lista De Autos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 204, 255));
        jButton2.setFont(new java.awt.Font("Unispace", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Lista De Empleados");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        TablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "NOMBRE", "APELLIDO", "EDAD", "CI", "NRO CELULAR", "AÑOS DE EXP", "SALARIO"
            }
        ));
        jScrollPane2.setViewportView(TablaEmpleados);

        jButton4.setBackground(new java.awt.Color(51, 204, 255));
        jButton4.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Lista de Registros de Alquiler");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        TablaRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "NOMBRE", "APELLIDO", "EDAD", "CI", "NRO CELULAR", "NRO VEHICULOS"
            }
        ));
        jScrollPane7.setViewportView(TablaRegistro);

        jButton3.setBackground(new java.awt.Color(51, 204, 255));
        jButton3.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Lista De Motos");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        TablaMotos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "MARCA", "MODELO", "PLACA", "COLOR", "AÑO", "TIPO", "CAPACIDAD", "ALQUILADO", "PRECIO"
            }
        ));
        jScrollPane3.setViewportView(TablaMotos);

        jButton5.setBackground(new java.awt.Color(51, 204, 255));
        jButton5.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Lista de Camiones");

        TablaAutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "MARCA", "MODELO", "PLACA", "COLOR", "AÑO", "TIPO", "CAPACIDAD", "ALQUILADO", "PRECIO"
            }
        ));
        jScrollPane5.setViewportView(TablaAutos);
        if (TablaAutos.getColumnModel().getColumnCount() > 0) {
            TablaAutos.getColumnModel().getColumn(5).setHeaderValue("TIPO");
        }

        TablaCamiones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "MARCA", "MODELO", "PLACA", "COLOR", "AÑO", "CAPACIDAD", "ALQUILADO", "CARGAMENTO", "PRECIO"
            }
        ));
        jScrollPane8.setViewportView(TablaCamiones);

        BotonActualizarDatos.setBackground(new java.awt.Color(51, 102, 255));
        BotonActualizarDatos.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        BotonActualizarDatos.setText("Actualizar Datos");
        BotonActualizarDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonActualizarDatosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 685, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 553, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 845, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 449, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(BotonActualizarDatos)
                                .addGap(18, 18, 18)
                                .addComponent(BotonCargarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 22, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BotonCargarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BotonActualizarDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 416, Short.MAX_VALUE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(502, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        jMenu1.setText("Agregar");

        AgregarAgencia.setText("Agencia");
        AgregarAgencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarAgenciaActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarAgencia);
        jMenu1.add(jSeparator1);

        AgregarEmpleado.setText("Empleado");
        AgregarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarEmpleadoActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarEmpleado);

        AgregarRegistro.setText("Registro");
        AgregarRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarRegistroActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarRegistro);
        jMenu1.add(jSeparator2);

        AgregarAuto.setText("Auto");
        AgregarAuto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarAutoActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarAuto);

        AgregarMoto.setText("Moto");
        AgregarMoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarMotoActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarMoto);

        AgregarCamion.setText("Camion");
        AgregarCamion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarCamionActionPerformed(evt);
            }
        });
        jMenu1.add(AgregarCamion);

        BarraMenu.add(jMenu1);

        jMenu2.setText("Alquilar");

        AlquilarAuto.setText("Auto");
        AlquilarAuto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlquilarAutoActionPerformed(evt);
            }
        });
        jMenu2.add(AlquilarAuto);

        AlquilarMoto.setText("Moto");
        AlquilarMoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlquilarMotoActionPerformed(evt);
            }
        });
        jMenu2.add(AlquilarMoto);

        AlquilarCamion.setText("Camion");
        AlquilarCamion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlquilarCamionActionPerformed(evt);
            }
        });
        jMenu2.add(AlquilarCamion);

        BarraMenu.add(jMenu2);

        jMenu3.setText("Eliminar");

        EliminarEmpleado.setText("Empleado");
        EliminarEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarEmpleadoActionPerformed(evt);
            }
        });
        jMenu3.add(EliminarEmpleado);

        EliminarRegistro.setText("Registro");
        EliminarRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarRegistroActionPerformed(evt);
            }
        });
        jMenu3.add(EliminarRegistro);

        EliminarAuto.setText("Auto");
        EliminarAuto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarAutoActionPerformed(evt);
            }
        });
        jMenu3.add(EliminarAuto);

        EliminarMoto.setText("Moto");
        EliminarMoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarMotoActionPerformed(evt);
            }
        });
        jMenu3.add(EliminarMoto);

        EliminarCamion.setText("Camion");
        EliminarCamion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarCamionActionPerformed(evt);
            }
        });
        jMenu3.add(EliminarCamion);

        BarraMenu.add(jMenu3);

        setJMenuBar(BarraMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1722, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonCargarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCargarDatosActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese Nombre de la Agencia que quiere cargar:");
        boolean encontrado = false;

        DefaultTableModel modelo = (DefaultTableModel) TablaEmpleados.getModel();
        modelo.setRowCount(0); // Limpia tabla
        DefaultTableModel modelo1 = (DefaultTableModel) TablaAutos.getModel();
        modelo1.setRowCount(0);
        DefaultTableModel modelo2 = (DefaultTableModel) TablaMotos.getModel();
        modelo2.setRowCount(0);
        DefaultTableModel modelo3 = (DefaultTableModel) TablaCamiones.getModel();
        modelo3.setRowCount(0);
        DefaultTableModel modelo4 = (DefaultTableModel) TablaRegistro.getModel();
        modelo4.setRowCount(0);
        File archivo = new File(ArchAgen.getNomArch());
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(this, "No hay datos de agencias guardados aún.");
            return;
        }

        try (ObjectInputStream arch = new ObjectInputStream(new FileInputStream(archivo))) {
            while (true) {
                try {
                    AgenciaDeAlquilerDeVehiculos agencia = (AgenciaDeAlquilerDeVehiculos) arch.readObject();
                    if (nombreAgencia.equalsIgnoreCase(agencia.getNombre())) {
                        Titulo.setText(agencia.getNombre());
                        StringBuilder sb = new StringBuilder();
                        sb.append("- Numero de Empleados: ").append(agencia.getNroEmpleados())
                                .append(" \n-Capacidad Maxima de Vehiculos: ").append(agencia.getCapacidadMaxima())
                                .append(" \n-Numero de Autos: ").append(agencia.getNroAutos())
                                .append(" \n-Numero de Motos: ").append(agencia.getNroMotos())
                                .append(" \n-Numero de Camiones: ").append(agencia.getNroCamiones())
                                .append(" \n-Total de Vehiculos: ").append(agencia.getTotalVehiculos());

                        AreaDeDatosDeAgencia.append(sb.toString());
                        encontrado = true;
                        for (int i = 0; i < agencia.getNroEmpleados(); i++) {
                            Empleado e = agencia.getE(i);
                            Object[] fila = {e.getNombre(), e.getApellido(), e.getEdad(), e.getCi(), e.getNroCelular(), e.getAñosdeXp()
                            };
                            modelo.addRow(fila);
                        }
                        for (int i = 0; i < agencia.getNroAutos(); i++) {
                            Auto a = agencia.getA(i);
                            Object[] fila = {
                                a.getMarca(), a.getModelo(), a.getPlaca(), a.getColor(), a.getAño(), a.getTipo(), a.getCapacidad(), a.getAlquilado(), a.getPrecio(),};
                            modelo1.addRow(fila);
                        }
                        for (int i = 0; i < agencia.getNroMotos(); i++) {
                            Moto m = agencia.getM(i);
                            Object[] fila = {
                                m.getMarca(), m.getModelo(), m.getPlaca(), m.getColor(), m.getAño(), m.getTipo(), m.getCapacidad(), m.getAlquilado(), m.getPrecio(),};
                            modelo2.addRow(fila);
                        }
                        for (int i = 0; i < agencia.getNroCamiones(); i++) {
                            Camion c = agencia.getC(i);
                            Object[] fila = {
                                c.getMarca(), c.getModelo(), c.getPlaca(), c.getColor(), c.getAño(), c.getCapacidad(), c.getCargamento(), c.getAlquilado(), c.getPrecio(),};
                            modelo3.addRow(fila);
                        }
                        for (int i = 0; i < agencia.getNroCamiones(); i++) {
                            RegistroDeAlquiler r = agencia.getR(i);
                            Persona p = r.getP();
                            Object[] fila = {
                                p.getNombre(), p.getApellido(), p.getEdad(), p.getCi(), p.getNroCelular(), r.getTotalVehiculos(),};
                            modelo4.addRow(fila);
                        }
                        arch.close();
                        break;
                    }
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error al leer archivo: " + e.getMessage());
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(this, "Agencia no encontrada.");
        }
    }//GEN-LAST:event_BotonCargarDatosActionPerformed

    private void AgregarAgenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarAgenciaActionPerformed

        String nombreAgencia = JOptionPane.showInputDialog("Ingrese Nombre de la Agencia:");
        String cantidadMaxAgencia = JOptionPane.showInputDialog("Ingrese la Capacidad Máxima de Vehículos:");

        try {
            int cantidadMax = Integer.parseInt(cantidadMaxAgencia);
            ArchAgen.AgregarAgencia(nombreAgencia, cantidadMax);
            AgenciaDeAlquilerDeVehiculos agen = new AgenciaDeAlquilerDeVehiculos(nombreAgencia, cantidadMax);
            A[nroAgen] = agen;
            nroAgen++;
            JOptionPane.showMessageDialog(this, "Agencia agregada correctamente.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un número válido para la capacidad.");
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error al agregar agencia: " + e.getMessage());
        }

    }//GEN-LAST:event_AgregarAgenciaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void AgregarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarEmpleadoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del Empleado:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido del Empleado:");
        String edadE = JOptionPane.showInputDialog("Ingrese la edad del Empleado:");
        String nroCelularE = JOptionPane.showInputDialog("Ingrese el número de celular del Empleado:");
        String ciE = JOptionPane.showInputDialog("Ingrese el CI del Empleado:");
        String añosXpE = JOptionPane.showInputDialog("Ingrese los años de experiencia del Empleado:");
        String salarioE = JOptionPane.showInputDialog("Ingrese el Salario del Empleado:");
        try {
            int edad = Integer.parseInt(edadE);
            int nroCel = Integer.parseInt(nroCelularE);
            int ci = Integer.parseInt(ciE);
            int añosEx = Integer.parseInt(añosXpE);
            int salario = Integer.parseInt(salarioE);
            if (edad < 18 || edad > 100) {
                JOptionPane.showMessageDialog(this, "Edad inválida. Debe estar entre 18 y 100.");
                return;
            }
            if (añosEx < 0) {
                JOptionPane.showMessageDialog(this, "Los años de experiencia no pueden ser negativos.");
                return;
            }
            if (salario < 0) {
                JOptionPane.showMessageDialog(this, "El salario no puede ser negativo.");
                return;
            }
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    Empleado em = new Empleado(nombre, apellido, edad, nroCel, ci, añosEx, salario);
                    A[i].agregarEmpleado(em);
                }
            }

            DefaultTableModel modelo = (DefaultTableModel) TablaEmpleados.getModel();
            Object[] fila = {nombre, apellido, edad, ci, nroCel, añosEx, salario};
            modelo.addRow(fila);
            JOptionPane.showMessageDialog(this, "Empleado agregado correctamente a la agencia: " + nombreAgencia);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error: Ingrese valores numéricos válidos para edad, celular, CI y experiencia.");
        }
    }//GEN-LAST:event_AgregarEmpleadoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void AgregarAutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarAutoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String marca = JOptionPane.showInputDialog("Ingrese Marca Del Auto:");
        String modelo = JOptionPane.showInputDialog("Ingrese Modelo Del Auto:");
        String color = JOptionPane.showInputDialog("Ingrese El Color Del Auto:");
        String añoA = JOptionPane.showInputDialog("Ingrese el Año del Auto:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa Del Auto:");
        String capacidadA = JOptionPane.showInputDialog("Ingrese la Capacidad Del Auto:");
        String precioA = JOptionPane.showInputDialog("Ingrese el Precio Del Auto:");
        String tipo = JOptionPane.showInputDialog("Ingrese el Tipo del Auto:");
        try {
            int año = Integer.parseInt(añoA);
            int capacidad = Integer.parseInt(capacidadA);
            int precio = Integer.parseInt(precioA);
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    Auto auto = new Auto(marca, modelo, color, año, placa, capacidad, precio, tipo);
                    A[i].agregarAuto(auto);
                }
            }
            DefaultTableModel modelo1 = (DefaultTableModel) TablaAutos.getModel();
            Object[] fila = {marca, modelo, placa, color, año, tipo, capacidad,"no", precio};
            modelo1.addRow(fila);
            JOptionPane.showMessageDialog(this, "Auto agregado correctamente a la agencia: " + nombreAgencia);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar Auto: " + e.getMessage());
        }
    }//GEN-LAST:event_AgregarAutoActionPerformed

    private void AgregarMotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarMotoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String marca = JOptionPane.showInputDialog("Ingrese Marca de la Moto:");
        String modelo = JOptionPane.showInputDialog("Ingrese Modelo de la Moto:");
        String color = JOptionPane.showInputDialog("Ingrese El Color de la Moto:");
        String añoA = JOptionPane.showInputDialog("Ingrese el Año de la Moto");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa de la Moto:");
        String capacidadA = JOptionPane.showInputDialog("Ingrese la Capacidad de la Moto:");
        String precioA = JOptionPane.showInputDialog("Ingrese el Precio de la Moto:");
        String tipo = JOptionPane.showInputDialog("Ingrese el Tipo de la Moto:");
        try {
            int año = Integer.parseInt(añoA);
            int capacidad = Integer.parseInt(capacidadA);
            int precio = Integer.parseInt(precioA);
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    Moto moto = new Moto(marca, modelo, color, año, placa, capacidad, precio, tipo);
                    A[i].agregarMoto(moto);
                }
            }
            DefaultTableModel modelo2 = (DefaultTableModel) TablaMotos.getModel();
            Object[] fila = {marca, modelo, placa, color, año, tipo ,capacidad,"no",precio};
            modelo2.addRow(fila);
            JOptionPane.showMessageDialog(this, "Moto agregado correctamente a la agencia: " + nombreAgencia);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar Moto: " + e.getMessage());
        }
    }//GEN-LAST:event_AgregarMotoActionPerformed

    private void AgregarCamionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarCamionActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String marca = JOptionPane.showInputDialog("Ingrese Marca Del Camion:");
        String modelo = JOptionPane.showInputDialog("Ingrese Modelo Del Camion:");
        String color = JOptionPane.showInputDialog("Ingrese El Color Del Camion:");
        String añoA = JOptionPane.showInputDialog("Ingrese el Año del Camion:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa Del Camion:");
        String capacidadA = JOptionPane.showInputDialog("Ingrese la Capacidad Del Camion:");
        String precioA = JOptionPane.showInputDialog("Ingrese el Precio Del Camion:");
        String cargamento = JOptionPane.showInputDialog("El Camion lleva Cargamento? si/no :");
        try {
            int año = Integer.parseInt(añoA);
            int capacidad = Integer.parseInt(capacidadA);
            int precio = Integer.parseInt(precioA);
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    Camion camion = new Camion(marca, modelo, color, año, placa, capacidad, precio, cargamento);
                    A[i].agregarCamion(camion);
                }
            }
            DefaultTableModel modelo3 = (DefaultTableModel) TablaCamiones.getModel();
            Object[] fila = {marca, modelo, placa, color, año, capacidad,"no", cargamento ,precio};
            modelo3.addRow(fila);

            JOptionPane.showMessageDialog(this, "Camion agregado correctamente a la agencia: " + nombreAgencia);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Camion al agregar Auto: " + e.getMessage());
        }


    }//GEN-LAST:event_AgregarCamionActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void AlquilarAutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlquilarAutoActionPerformed

        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la Persona:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido de la Persona:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa del Auto:");
        for (int i = 0; i < nroAgen; i++) {
            if (A[i].getNombre().equals(nombreAgencia)) {
                for (int j = 0; j < A[i].getNroAutos(); j++) {
                    Auto a = A[i].getA(j);
                    if (a.getPlaca().equals(placa) && a.getAlquilado().equals("no")) {
                        a.setAlquilado("si");
                        A[i].setA(a, j);
                        A[i].alquilarVehiculo(nombre, apellido, a);
                        break;
                    }

                }
            }
        }
    }//GEN-LAST:event_AlquilarAutoActionPerformed

    private void AgregarRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarRegistroActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la Persona:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido de la Persona:");
        String edadP = JOptionPane.showInputDialog("Ingrese la edad de la Persona :");
        String nroCelularP = JOptionPane.showInputDialog("Ingrese el número de celular de la Persona:");
        String ciP = JOptionPane.showInputDialog("Ingrese el CI de la Persona");
        try {
            int edad = Integer.parseInt(edadP);
            int nroCel = Integer.parseInt(nroCelularP);
            int ci = Integer.parseInt(ciP);
            if (edad < 18 || edad > 100) {
                JOptionPane.showMessageDialog(this, "Edad inválida. Debe estar entre 18 y 100.");
                return;
            }

            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    Persona p = new Persona(nombre, apellido, edad, nroCel, ci);
                    A[i].AgregarRegistroDeAlquiler(p);
                }
            }
            int totalVehiculos = 0;
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    for (int j = 0; j < A[i].getNroRegistroAlquiler(); j++) {
                        RegistroDeAlquiler r = A[i].getR(i);
                        Persona pe = r.getP();
                        if (pe.getNombre().equals(nombre) && pe.getApellido().equals(apellido)) {
                            totalVehiculos = r.getTotalVehiculos();
                        }
                    }
                }
            }
            DefaultTableModel modelo4 = (DefaultTableModel) TablaRegistro.getModel();
            Object[] fila = {nombre, apellido, edad, ci, nroCel, totalVehiculos};
            modelo4.addRow(fila);
            JOptionPane.showMessageDialog(this, "Registro agregado correctamente a la agencia: " + nombreAgencia);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Registro al agregar Auto: " + e.getMessage());
        }
    }//GEN-LAST:event_AgregarRegistroActionPerformed

    private void AlquilarMotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlquilarMotoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la Persona:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido de la Persona:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa de la moto:");
        for (int i = 0; i < nroAgen; i++) {
            if (A[i].getNombre().equals(nombreAgencia)) {
                for (int j = 0; j < A[i].getNroMotos(); j++) {
                    Moto m = A[i].getM(j);
                    if (m.getPlaca().equals(placa) && m.getAlquilado().equals("no")) {
                        m.setAlquilado("si");
                        A[i].setM(m, j);
                        A[i].alquilarVehiculo(nombre, apellido, m);
                        break;
                    }
                }
            }
        }
    }//GEN-LAST:event_AlquilarMotoActionPerformed

    private void AlquilarCamionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlquilarCamionActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la Persona:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido de la Persona:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa del Camion:");
        for (int i = 0; i < nroAgen; i++) {
            if (A[i].getNombre().equals(nombreAgencia)) {
                for (int j = 0; j < A[i].getNroCamiones(); j++) {
                    Camion c = A[i].getC(j);
                    if (c.getPlaca().equals(placa) && c.getAlquilado().equals("no")) {
                        c.setAlquilado("si");
                        A[i].setC(c, j);
                        A[i].alquilarVehiculo(nombre, apellido, c);
                        break;
                    }
                }
            }
        }
    }//GEN-LAST:event_AlquilarCamionActionPerformed

    private void BotonActualizarDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonActualizarDatosActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese Nombre de la Agencia que quiere cargar:");

        DefaultTableModel modelo = (DefaultTableModel) TablaEmpleados.getModel();
        modelo.setRowCount(0); // Limpia tabla
        DefaultTableModel modelo1 = (DefaultTableModel) TablaAutos.getModel();
        modelo1.setRowCount(0);
        DefaultTableModel modelo2 = (DefaultTableModel) TablaMotos.getModel();
        modelo2.setRowCount(0);
        DefaultTableModel modelo3 = (DefaultTableModel) TablaCamiones.getModel();
        modelo3.setRowCount(0);
        DefaultTableModel modelo4 = (DefaultTableModel) TablaRegistro.getModel();
        modelo4.setRowCount(0);
        for(int i=0;i<nroAgen;i++){
        if (nombreAgencia.equals(A[i].getNombre())) {
            
            Titulo.setText(A[i].getNombre()); 
            AreaDeDatosDeAgencia.setText("");
            StringBuilder sb = new StringBuilder();
            sb.append("- Numero de Empleados: ").append(A[i].getNroEmpleados())
                    .append(" \n-Capacidad Maxima de Vehiculos: ").append(A[i].getCapacidadMaxima())
                    .append(" \n-Numero de Autos: ").append(A[i].getNroAutos())
                    .append(" \n-Numero de Motos: ").append(A[i].getNroMotos())
                    .append(" \n-Numero de Camiones: ").append(A[i].getNroCamiones())
                    .append(" \n-Total de Vehiculos: ").append(A[i].getTotalVehiculos());

            AreaDeDatosDeAgencia.append(sb.toString());
            for (int j = 0; j < A[i].getNroEmpleados(); j++) {
                Empleado e = A[i].getE(i);
                Object[] fila = {e.getNombre(), e.getApellido(), e.getEdad(), e.getCi(), e.getNroCelular(), e.getAñosdeXp(),e.getSalario()
                };
                modelo.addRow(fila);
            }
            for (int j = 0; j < A[i].getNroAutos(); j++) {
                Auto a = A[i].getA(j);
                Object[] fila = {
                    a.getMarca(), a.getModelo(), a.getPlaca(), a.getColor(), a.getAño(), a.getTipo(), a.getCapacidad(), a.getAlquilado(), a.getPrecio(),};
                modelo1.addRow(fila);
            }
            for (int j = 0; j < A[i].getNroMotos(); j++) {
                Moto m = A[i].getM(j);
                Object[] fila = {
                    m.getMarca(), m.getModelo(), m.getPlaca(), m.getColor(), m.getAño(), m.getTipo(), m.getCapacidad(), m.getAlquilado(), m.getPrecio(),};
                modelo2.addRow(fila);
            }
            for (int j = 0; j < A[i].getNroCamiones(); j++) {
                Camion c = A[i].getC(j);
                Object[] fila = {
                    c.getMarca(), c.getModelo(), c.getPlaca(), c.getColor(), c.getAño(), c.getCapacidad(), c.getCargamento(), c.getAlquilado(), c.getPrecio(),};
                modelo3.addRow(fila);
            }
            for (int j = 0; j < A[i].getNroRegistroAlquiler(); j++) {
                RegistroDeAlquiler r = A[i].getR(j);
                Persona p = r.getP();
                Object[] fila = {
                    p.getNombre(), p.getApellido(), p.getEdad(), p.getCi(), p.getNroCelular(), r.getTotalVehiculos(),};
                modelo4.addRow(fila);
            }

            break;
        }
        }
    }//GEN-LAST:event_BotonActualizarDatosActionPerformed

    private void EliminarEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarEmpleadoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del Empleado:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido del Empleado:");
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    A[i].EliminarEmpleado(nombre, apellido);
                }
            }   
    }//GEN-LAST:event_EliminarEmpleadoActionPerformed

    private void EliminarRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarRegistroActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre de la Persona:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido de la Persona:");
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    A[i].EliminarRegistro(nombre, apellido);
                }
            }   
    }//GEN-LAST:event_EliminarRegistroActionPerformed

    private void EliminarAutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarAutoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa del Auto :");
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    A[i].EliminarAuto(placa);
                }
            }   
    }//GEN-LAST:event_EliminarAutoActionPerformed

    private void EliminarMotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarMotoActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa de la Moto :");
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    A[i].EliminarMoto(placa);
                }
            }   
    }//GEN-LAST:event_EliminarMotoActionPerformed

    private void EliminarCamionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarCamionActionPerformed
        String nombreAgencia = JOptionPane.showInputDialog("Ingrese el nombre de la Agencia:");
        String placa = JOptionPane.showInputDialog("Ingrese la Placa del Camion :");
            for (int i = 0; i < nroAgen; i++) {
                if (A[i].getNombre().equals(nombreAgencia)) {
                    A[i].EliminarCamion(placa);
                }
            }  
    }//GEN-LAST:event_EliminarCamionActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AgenciaDeVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AgenciaDeVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AgenciaDeVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AgenciaDeVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AgenciaDeVehiculos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AgregarAgencia;
    private javax.swing.JMenuItem AgregarAuto;
    private javax.swing.JMenuItem AgregarCamion;
    private javax.swing.JMenuItem AgregarEmpleado;
    private javax.swing.JMenuItem AgregarMoto;
    private javax.swing.JMenuItem AgregarRegistro;
    private javax.swing.JMenuItem AlquilarAuto;
    private javax.swing.JMenuItem AlquilarCamion;
    private javax.swing.JMenuItem AlquilarMoto;
    private javax.swing.JTextArea AreaDeDatosDeAgencia;
    private javax.swing.JMenuBar BarraMenu;
    private javax.swing.JButton BotonActualizarDatos;
    private javax.swing.JButton BotonCargarDatos;
    private javax.swing.JMenuItem EliminarAuto;
    private javax.swing.JMenuItem EliminarCamion;
    private javax.swing.JMenuItem EliminarEmpleado;
    private javax.swing.JMenuItem EliminarMoto;
    private javax.swing.JMenuItem EliminarRegistro;
    private javax.swing.JTable TablaAutos;
    private javax.swing.JTable TablaCamiones;
    private javax.swing.JTable TablaEmpleados;
    private javax.swing.JTable TablaMotos;
    private javax.swing.JTable TablaRegistro;
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
